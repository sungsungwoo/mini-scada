#!/usr/bin/env bash
set -euo pipefail

AWS_REGION="ap-northeast-2"
ECR_REGISTRY="237586138150.dkr.ecr.${AWS_REGION}.amazonaws.com"
IMAGE_TAG="${1:-latest}"

cd /opt/mini-scada

aws ecr get-login-password --region "$AWS_REGION" \
  | docker login --username AWS --password-stdin "$ECR_REGISTRY"

sed -i "s/^IMAGE_TAG=.*/IMAGE_TAG=${IMAGE_TAG}/" .env.prod

docker compose --env-file .env.prod -f docker-compose.prod.yml pull backend frontend
docker compose --env-file .env.prod -f docker-compose.prod.yml up -d --remove-orphans
docker compose --env-file .env.prod -f docker-compose.prod.yml up -d --force-recreate caddy
docker image prune -af
